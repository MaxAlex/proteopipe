d = { 'settings': { },
  'syms': { }}