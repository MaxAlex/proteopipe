# legacy module: base.py 
from peptdeep.model.building_block import *
from peptdeep.model.model_interface import *