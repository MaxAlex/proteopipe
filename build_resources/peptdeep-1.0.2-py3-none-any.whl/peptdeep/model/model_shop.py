from peptdeep.model.generic_property_prediction import *
