from peptdeep.spec_lib import (
    predict_lib, translate, library_factory
)